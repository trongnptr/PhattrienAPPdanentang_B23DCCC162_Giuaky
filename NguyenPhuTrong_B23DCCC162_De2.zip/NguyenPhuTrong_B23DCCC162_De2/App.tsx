import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import HomeScreen from './src/screens/HomeScreen';
import FieldFormScreen from './src/screens/FieldFormScreen';
import FieldDetailScreen from './src/screens/FieldDetailScreen';
import { initData } from './src/utils/storage';

const Stack = createNativeStackNavigator();

export default function App() {
  useEffect(() => {
    initData();
  }, []);

  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home" screenOptions={{ headerStyle: { backgroundColor: '#007BFF' }, headerTintColor: '#fff' }}>
          <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Quản lý Sân Bóng' }} />
          <Stack.Screen name="FieldForm" component={FieldFormScreen} options={({ route }: any) => ({ title: route.params?.field ? 'Sửa sân' : 'Thêm sân mới' })} />
          <Stack.Screen name="FieldDetail" component={FieldDetailScreen} options={{ title: 'Chi tiết sân' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
