import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Modal, KeyboardAvoidingView, Platform, ScrollView, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { Field, Booking } from '../types';
import { colors } from '../theme/colors';
import { formatCurrency, checkOverlap } from '../utils/helpers';
import { getBookings, saveBookings } from '../utils/storage';

interface Props { visible: boolean; field: Field; onClose: () => void; onSuccess: () => void; }

export default function BookingModal({ visible, field, onClose, onSuccess }: Props) {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [startHour, setStartHour] = useState('');
  const [hours, setHours] = useState('');
  const [errors, setErrors] = useState<any>({});

  const handleBook = async () => {
    let errs: any = {};
    if (!customerName.trim()) errs.name = 'Vui lòng nhập tên khách hàng';
    if (!/^0\d{9}$/.test(phone)) errs.phone = 'SĐT không hợp lệ (10 số, đầu 0)';
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(date)) errs.date = 'Sai định dạng ngày (dd/mm/yyyy)';
    const sHour = parseInt(startHour);
    if (isNaN(sHour) || sHour < 6 || sHour > 22) errs.startHour = 'Giờ đặt từ 6 - 22';
    const hrs = parseInt(hours);
    if (isNaN(hrs) || hrs < 1 || hrs > 3) errs.hours = 'Số giờ thuê từ 1 - 3 giờ';
    if (sHour + hrs > 23) errs.hours = 'Giờ kết thúc không được qua 23h';

    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const existingBookings = await getBookings();
    const newBooking: Booking = { id: Date.now().toString(), fieldId: field.id, customerName: customerName.trim(), phone, date, startHour: sHour, hours: hrs };

    if (checkOverlap(existingBookings, newBooking)) {
      Alert.alert('Trùng lịch', 'Khung giờ này đã có người đặt, vui lòng chọn giờ khác!');
      return;
    }

    await saveBookings([...existingBookings, newBooking]);
    Alert.alert('Thành công', 'Đã lưu lịch đặt sân!');
    setCustomerName(''); setPhone(''); setDate(''); setStartHour(''); setHours('');
    onSuccess();
  };

  const calculateTotal = () => {
    const hrs = parseInt(hours);
    if (!isNaN(hrs) && hrs > 0) return formatCurrency(field.pricePerHour * hrs).replace('/giờ', '');
    return '0 đ';
  };

  return (
    <Modal visible={visible} animationType="fade" transparent>
      <View style={styles.overlay}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalContainer}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.modalHeader}>
              <Text style={styles.title}>ĐẶT SÂN {field.name.toUpperCase()}</Text>
              <TouchableOpacity onPress={onClose}><Icon name="close" size={24} color={colors.textLight} /></TouchableOpacity>
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Tên người đặt *</Text>
              <View style={[styles.inputWrapper, errors.name && styles.inputError]}>
                <Icon name="account-edit" size={20} color={colors.textLight} />
                <TextInput style={styles.input} value={customerName} onChangeText={setCustomerName} placeholder="Ví dụ: Nguyễn Phú Trọng" />
              </View>
              {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Số điện thoại liên hệ *</Text>
              <View style={[styles.inputWrapper, errors.phone && styles.inputError]}>
                <Icon name="phone" size={20} color={colors.textLight} />
                <TextInput style={styles.input} value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="0xxxxxxxxx" />
              </View>
              {errors.phone && <Text style={styles.errorText}>{errors.phone}</Text>}
            </View>

            <View style={styles.rowInputs}>
              <View style={styles.flex1}>
                <Text style={styles.label}>Ngày đặt *</Text>
                <View style={[styles.inputWrapper, errors.date && styles.inputError]}>
                  <Icon name="calendar" size={20} color={colors.textLight} />
                  <TextInput style={styles.input} value={date} onChangeText={setDate} placeholder="25/10/2026" />
                </View>
                {errors.date && <Text style={styles.errorText}>{errors.date}</Text>}
              </View>
              <View style={styles.flex1}>
                <Text style={styles.label}>Giờ bắt đầu *</Text>
                <View style={[styles.inputWrapper, errors.startHour && styles.inputError]}>
                  <Icon name="clock-outline" size={20} color={colors.textLight} />
                  <TextInput style={styles.input} value={startHour} onChangeText={setStartHour} keyboardType="numeric" placeholder="VD: 17" />
                </View>
                {errors.startHour && <Text style={styles.errorText}>{errors.startHour}</Text>}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Thời lượng (giờ) *</Text>
              <View style={[styles.inputWrapper, errors.hours && styles.inputError]}>
                <Icon name="timer-sand" size={20} color={colors.textLight} />
                <TextInput style={styles.input} value={hours} onChangeText={setHours} keyboardType="numeric" placeholder="Từ 1 đến 3 giờ" />
              </View>
              {errors.hours && <Text style={styles.errorText}>{errors.hours}</Text>}
            </View>

            <View style={styles.summaryBox}>
              <Text style={styles.summaryLabel}>Tổng tiền thanh toán</Text>
              <Text style={styles.totalText}>{calculateTotal()}</Text>
            </View>

            <View style={styles.actions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={onClose}><Text style={styles.cancelBtnText}>Huỷ bỏ</Text></TouchableOpacity>
              <TouchableOpacity style={styles.bookBtn} onPress={handleBook}><Text style={styles.bookBtnText}>Xác nhận đặt</Text></TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 20 },
  modalContainer: { backgroundColor: '#fff', padding: 24, borderRadius: 16, maxHeight: '90%', elevation: 5 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, borderBottomWidth: 1, borderBottomColor: colors.border, paddingBottom: 10 },
  title: { fontSize: 20, fontWeight: '900', color: colors.primary },
  inputGroup: { marginBottom: 15 },
  rowInputs: { flexDirection: 'row', gap: 15, marginBottom: 15 },
  flex1: { flex: 1 },
  label: { fontSize: 14, fontWeight: 'bold', color: colors.text, marginBottom: 6 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 12 },
  inputError: { borderColor: colors.error, backgroundColor: '#FEF2F2' },
  input: { flex: 1, paddingVertical: 12, paddingHorizontal: 8, fontSize: 16, color: colors.text },
  errorText: { color: colors.error, fontSize: 12, marginTop: 4, fontStyle: 'italic' },
  summaryBox: { backgroundColor: '#ECFDF5', padding: 15, borderRadius: 10, alignItems: 'center', marginVertical: 15, borderWidth: 1, borderColor: '#A7F3D0' },
  summaryLabel: { color: colors.primaryDark, fontSize: 14, fontWeight: 'bold' },
  totalText: { fontSize: 24, fontWeight: '900', color: colors.primary, marginTop: 5 },
  actions: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  cancelBtn: { flex: 1, backgroundColor: '#F3F4F6', paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
  cancelBtnText: { color: colors.text, fontWeight: 'bold', fontSize: 16 },
  bookBtn: { flex: 1, backgroundColor: colors.primary, paddingVertical: 14, borderRadius: 10, alignItems: 'center' },
  bookBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});