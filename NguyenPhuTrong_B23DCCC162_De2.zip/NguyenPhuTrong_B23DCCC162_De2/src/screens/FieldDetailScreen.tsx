import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { getBookings, saveBookings } from '../utils/storage';
import { Field, Booking } from '../types';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/helpers';
import BookingModal from '../components/BookingModal';

export default function FieldDetailScreen({ route }: any) {
  const { field } = route.params as { field: Field };
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [modalVisible, setModalVisible] = useState(false);

  const loadBookings = async () => {
    const allBookings = await getBookings();
    setBookings(allBookings.filter(b => b.fieldId === field.id));
  };

  useFocusEffect(useCallback(() => { loadBookings(); }, []));

  const handleCancelBooking = (bookingId: string) => {
    Alert.alert('Huỷ lịch', 'Bạn có chắc chắn muốn huỷ lịch đặt này?', [
      { text: 'Bỏ qua', style: 'cancel' },
      { text: 'Xác nhận huỷ', style: 'destructive', onPress: async () => {
          const allBookings = await getBookings();
          const newBookings = allBookings.filter(b => b.id !== bookingId);
          await saveBookings(newBookings);
          loadBookings();
        }
      }
    ]);
  };

  const renderBooking = ({ item }: { item: Booking }) => (
    <View style={styles.bookingCard}>
      <View style={styles.bookingInfo}>
        <View style={styles.bookingHeader}>
          <Icon name="account" size={18} color={colors.primary} />
          <Text style={styles.customerName}>{item.customerName}</Text>
        </View>
        <View style={styles.row}>
          <Icon name="phone" size={16} color={colors.textLight} />
          <Text style={styles.bookingDetail}>{item.phone}</Text>
        </View>
        <View style={styles.row}>
          <Icon name="calendar-clock" size={16} color={colors.textLight} />
          <Text style={styles.bookingDetail}>{item.date} | <Text style={{fontWeight:'bold', color:colors.text}}>{item.startHour}h - {item.startHour + item.hours}h</Text></Text>
        </View>
      </View>
      <TouchableOpacity style={styles.cancelBtn} onPress={() => handleCancelBooking(item.id)}>
        <Icon name="close-circle" size={24} color={colors.danger} />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.infoCard}>
        <View style={{flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10}}>
          <View style={styles.iconBox}><Icon name="soccer-field" size={32} color={colors.primary} /></View>
          <View>
            <Text style={styles.name}>{field.name}</Text>
            <View style={[styles.badge, field.status === 'Hoạt động' ? styles.badgeActive : styles.badgeMaintenance]}>
              <Text style={[styles.badgeText, {color: field.status === 'Hoạt động' ? colors.primaryDark : colors.warning}]}>{field.status}</Text>
            </View>
          </View>
        </View>
        <View style={styles.divider} />
        <View style={styles.rowInfo}>
          <Text style={styles.label}>Loại sân</Text>
          <Text style={styles.value}>{field.type}</Text>
        </View>
        <View style={styles.rowInfo}>
          <Text style={styles.label}>Giá thuê</Text>
          <Text style={styles.price}>{formatCurrency(field.pricePerHour)}</Text>
        </View>
      </View>

      <View style={styles.sectionHeader}>
        <Icon name="clipboard-text-clock" size={20} color={colors.text} />
        <Text style={styles.sectionTitle}>Lịch đã đặt</Text>
      </View>

      <FlatList
        data={bookings}
        keyExtractor={item => item.id}
        renderItem={renderBooking}
        ListEmptyComponent={<Text style={styles.empty}>Sân chưa có lịch đặt nào.</Text>}
        contentContainerStyle={{ paddingBottom: 100 }}
      />

      <View style={styles.footer}>
        <TouchableOpacity 
          style={[styles.bookBtn, field.status === 'Bảo trì' && styles.bookBtnDisabled]}
          disabled={field.status === 'Bảo trì'}
          onPress={() => setModalVisible(true)}
        >
          <Icon name="calendar-plus" size={24} color="#fff" />
          <Text style={styles.bookBtnText}>{field.status === 'Bảo trì' ? 'Sân đang bảo trì' : 'ĐẶT SÂN NGAY'}</Text>
        </TouchableOpacity>
      </View>

      <BookingModal visible={modalVisible} field={field} onClose={() => setModalVisible(false)} onSuccess={() => { setModalVisible(false); loadBookings(); }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 15 },
  infoCard: { backgroundColor: '#fff', padding: 20, borderRadius: 16, elevation: 4, shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 10, marginBottom: 20 },
  iconBox: { backgroundColor: '#ECFDF5', padding: 12, borderRadius: 12 },
  name: { fontSize: 24, fontWeight: '900', color: colors.text, marginBottom: 4 },
  badge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  badgeActive: { backgroundColor: '#D1FAE5' },
  badgeMaintenance: { backgroundColor: '#FEF3C7' },
  badgeText: { fontSize: 12, fontWeight: 'bold' },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 15 },
  rowInfo: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  label: { fontSize: 16, color: colors.textLight },
  value: { fontSize: 16, fontWeight: '600', color: colors.text },
  price: { fontSize: 18, fontWeight: 'bold', color: colors.danger },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: colors.text },
  bookingCard: { backgroundColor: '#fff', padding: 16, borderRadius: 12, marginBottom: 10, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderLeftWidth: 4, borderLeftColor: colors.primary, elevation: 2 },
  bookingInfo: { flex: 1 },
  bookingHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  customerName: { fontSize: 16, fontWeight: 'bold', color: colors.text },
  row: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  bookingDetail: { color: colors.textLight, fontSize: 14 },
  cancelBtn: { padding: 8 },
  empty: { textAlign: 'center', color: colors.textLight, marginTop: 20, fontStyle: 'italic' },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: colors.border },
  bookBtn: { backgroundColor: colors.primary, flexDirection: 'row', justifyContent: 'center', gap: 10, padding: 16, borderRadius: 12, alignItems: 'center', elevation: 3 },
  bookBtnDisabled: { backgroundColor: colors.disabled },
  bookBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold' }
});