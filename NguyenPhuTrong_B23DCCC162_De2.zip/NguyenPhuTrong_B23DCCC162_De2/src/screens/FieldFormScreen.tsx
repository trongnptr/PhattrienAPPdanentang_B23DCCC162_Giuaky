import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { getFields, saveFields } from '../utils/storage';
import { Field } from '../types';
import { colors } from '../theme/colors';

export default function FieldFormScreen({ route, navigation }: any) {
  const editingField: Field | undefined = route.params?.field;

  const [name, setName] = useState(editingField?.name || '');
  const [type, setType] = useState<'5 người' | '7 người'>(editingField?.type || '5 người');
  const [price, setPrice] = useState(editingField?.pricePerHour?.toString() || '');
  const [status, setStatus] = useState<'Hoạt động' | 'Bảo trì'>(editingField?.status || 'Hoạt động');

  const [errors, setErrors] = useState<any>({});
  const [fields, setFields] = useState<Field[]>([]);

  useEffect(() => { getFields().then(setFields); }, []);

  const handleSave = async () => {
    let errs: any = {};
    if (!name.trim()) errs.name = 'Vui lòng nhập tên sân';
    if (fields.some(f => f.name.toLowerCase() === name.trim().toLowerCase() && f.id !== editingField?.id)) {
      errs.name = 'Tên sân bị trùng, vui lòng chọn tên khác';
    }
    const parsedPrice = parseInt(price);
    if (!price || isNaN(parsedPrice) || parsedPrice <= 0) {
      errs.price = 'Giá thuê phải là số lớn hơn 0';
    }

    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const newField: Field = { id: editingField ? editingField.id : Date.now().toString(), name: name.trim(), type, pricePerHour: parsedPrice, status };

    const updatedFields = editingField ? fields.map(f => f.id === editingField.id ? newField : f) : [...fields, newField];

    await saveFields(updatedFields);
    navigation.goBack();
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.formCard}>
          <Text style={styles.label}>Tên sân *</Text>
          <View style={[styles.inputWrapper, errors.name && styles.inputError]}>
            <Icon name="soccer-field" size={20} color={colors.textLight} />
            <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Nhập tên sân (VD: Sân A1)" />
          </View>
          {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

          <Text style={styles.label}>Loại sân</Text>
          <View style={styles.row}>
            {(['5 người', '7 người'] as const).map(t => (
              <TouchableOpacity key={t} style={[styles.choiceBtn, type === t && styles.choiceBtnActive]} onPress={() => setType(t)}>
                <Icon name={t === '5 người' ? 'account-multiple' : 'account-group'} size={20} color={type === t ? '#fff' : colors.textLight} />
                <Text style={type === t ? styles.choiceTextActive : styles.choiceText}>{t}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>Giá thuê mỗi giờ (VNĐ) *</Text>
          <View style={[styles.inputWrapper, errors.price && styles.inputError]}>
            <Icon name="cash" size={20} color={colors.textLight} />
            <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="Ví dụ: 300000" />
          </View>
          {errors.price && <Text style={styles.errorText}>{errors.price}</Text>}

          <Text style={styles.label}>Tình trạng</Text>
          <View style={styles.row}>
            {(['Hoạt động', 'Bảo trì'] as const).map(s => (
              <TouchableOpacity key={s} style={[styles.choiceBtn, status === s && (s === 'Hoạt động' ? styles.statusActive : styles.statusWarning)]} onPress={() => setStatus(s)}>
                <Icon name={s === 'Hoạt động' ? 'check-circle' : 'tools'} size={18} color={status === s ? '#fff' : colors.textLight} />
                <Text style={status === s ? styles.choiceTextActive : styles.choiceText}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
            <Icon name="content-save" size={24} color="#fff" />
            <Text style={styles.saveBtnText}>LƯU THÔNG TIN</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { padding: 15 },
  formCard: { backgroundColor: '#fff', padding: 20, borderRadius: 16, elevation: 3 },
  label: { fontSize: 15, fontWeight: 'bold', marginBottom: 8, marginTop: 15, color: colors.text },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 12 },
  inputError: { borderColor: colors.error, backgroundColor: '#FEF2F2' },
  input: { flex: 1, paddingVertical: 12, paddingHorizontal: 8, fontSize: 16, color: colors.text },
  errorText: { color: colors.error, fontSize: 12, marginTop: 4, fontStyle: 'italic' },
  row: { flexDirection: 'row', gap: 12 },
  choiceBtn: { flex: 1, flexDirection: 'row', justifyContent: 'center', gap: 8, padding: 12, borderWidth: 1, borderColor: colors.border, borderRadius: 10, alignItems: 'center', backgroundColor: '#F9FAFB' },
  choiceBtnActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  statusActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  statusWarning: { backgroundColor: colors.warning, borderColor: colors.warning },
  choiceText: { color: colors.text, fontWeight: '600' },
  choiceTextActive: { color: '#fff', fontWeight: 'bold' },
  saveBtn: { backgroundColor: colors.primary, flexDirection: 'row', justifyContent: 'center', gap: 10, padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 30, elevation: 2 },
  saveBtnText: { color: '#fff', fontSize: 16, fontWeight: '900' }
});