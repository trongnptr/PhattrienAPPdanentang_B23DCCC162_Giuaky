import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { getFields, getBookings, saveFields } from '../utils/storage';
import { Field } from '../types';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/helpers';

export default function HomeScreen({ navigation }: any) {
  const [fields, setFields] = useState<Field[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);

  const loadData = async () => {
    const loadedFields = await getFields();
    const loadedBookings = await getBookings();
    setFields(loadedFields);
    setBookings(loadedBookings);
  };

  useFocusEffect(useCallback(() => { loadData(); }, []));

  const activeCount = fields.filter(f => f.status === 'Hoạt động').length;

  const handleDelete = (field: Field) => {
    if (bookings.some(b => b.fieldId === field.id)) {
      Alert.alert('Lỗi xoá', 'Không thể xoá sân đang có khách đặt!');
      return;
    }
    Alert.alert('Xác nhận xoá', `Bạn có chắc chắn muốn xoá ${field.name}?`, [
      { text: 'Huỷ', style: 'cancel' },
      { text: 'Xoá', style: 'destructive', onPress: async () => {
          const newFields = fields.filter(f => f.id !== field.id);
          await saveFields(newFields);
          setFields(newFields);
        }
      }
    ]);
  };

  const renderItem = ({ item }: { item: Field }) => (
    <TouchableOpacity activeOpacity={0.8} style={styles.card} onPress={() => navigation.navigate('FieldDetail', { field: item })}>
      <View style={styles.cardHeader}>
        <View style={styles.nameContainer}>
          <Icon name="soccer-field" size={24} color={colors.primary} />
          <Text style={styles.name}>{item.name}</Text>
        </View>
        <View style={[styles.badge, item.status === 'Hoạt động' ? styles.badgeActive : styles.badgeMaintenance]}>
          <Text style={styles.badgeText}>{item.status}</Text>
        </View>
      </View>
      
      <View style={styles.cardBody}>
        <View style={styles.infoRow}>
          <Icon name="account-group" size={18} color={colors.textLight} />
          <Text style={styles.infoText}>Loại: {item.type}</Text>
        </View>
        <View style={styles.infoRow}>
          <Icon name="cash" size={18} color={colors.danger} />
          <Text style={styles.price}>{formatCurrency(item.pricePerHour)}</Text>
        </View>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity style={styles.editBtn} onPress={() => navigation.navigate('FieldForm', { field: item })}>
          <Icon name="pencil" size={16} color="#fff" />
          <Text style={styles.btnText}>Sửa</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(item)}>
          <Icon name="trash-can-outline" size={16} color="#fff" />
          <Text style={styles.btnText}>Xoá</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Tổng quan</Text>
          <Text style={styles.headerSubText}>
            <Text style={{color: colors.primary, fontWeight: 'bold'}}>{activeCount}</Text> / {fields.length} sân đang hoạt động
          </Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('FieldForm')}>
          <Icon name="plus-circle" size={20} color="#fff" />
          <Text style={styles.btnText}>Thêm sân</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={fields}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<View style={styles.emptyContainer}><Icon name="soccer" size={50} color={colors.disabled} /><Text style={styles.empty}>Chưa có dữ liệu sân bóng.</Text></View>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', padding: 20, alignItems: 'center', backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: colors.border },
  headerTitle: { fontSize: 20, fontWeight: '900', color: colors.text },
  headerSubText: { fontSize: 14, color: colors.textLight, marginTop: 4 },
  addBtn: { backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 8, gap: 6 },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  list: { padding: 15 },
  card: { backgroundColor: colors.card, padding: 16, borderRadius: 12, marginBottom: 15, elevation: 4, shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, borderBottomWidth: 1, borderBottomColor: colors.border, paddingBottom: 10 },
  nameContainer: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { fontSize: 18, fontWeight: 'bold', color: colors.text },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  badgeActive: { backgroundColor: '#D1FAE5' },
  badgeMaintenance: { backgroundColor: '#FEF3C7' },
  badgeText: { fontSize: 12, fontWeight: '700', color: colors.text },
  cardBody: { marginBottom: 12 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  infoText: { color: colors.textLight, fontSize: 15 },
  price: { color: colors.danger, fontWeight: '800', fontSize: 16 },
  actions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10 },
  editBtn: { backgroundColor: colors.secondary, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 6, gap: 4 },
  deleteBtn: { backgroundColor: colors.danger, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 6, gap: 4 },
  emptyContainer: { alignItems: 'center', marginTop: 80, gap: 10 },
  empty: { textAlign: 'center', color: colors.textLight, fontSize: 16 }
});