export const colors = {
  primary: '#10B981', // Xanh lá cây mướt (chuẩn sân cỏ)
  primaryDark: '#059669',
  secondary: '#3B82F6',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  background: '#F3F4F6', // Xám nhạt hiện đại
  card: '#FFFFFF',
  text: '#111827',
  textLight: '#6B7280',
  border: '#E5E7EB',
  error: '#EF4444',
  disabled: '#D1D5DB'
};