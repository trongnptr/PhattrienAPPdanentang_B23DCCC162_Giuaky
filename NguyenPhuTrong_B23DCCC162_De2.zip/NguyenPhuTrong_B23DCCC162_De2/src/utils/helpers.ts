import { Booking } from '../types';

export const formatCurrency = (amount: number) => {
  return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ' đ/giờ';
};

export const checkOverlap = (existingBookings: Booking[], newBooking: Booking) => {
  const dayBookings = existingBookings.filter(b => b.fieldId === newBooking.fieldId && b.date === newBooking.date && b.id !== newBooking.id);
  const newStart = newBooking.startHour;
  const newEnd = newStart + newBooking.hours;

  for (let b of dayBookings) {
    let bStart = b.startHour;
    let bEnd = bStart + b.hours;
    if (newStart < bEnd && newEnd > bStart) {
      return true;
    }
  }
  return false;
};